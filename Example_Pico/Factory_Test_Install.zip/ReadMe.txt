*** Spartan-6 LX9 MicroBoard Factory Test Flash Loader Instructions ***
------------------------------------------------------------------------

STEP 1)  Download the Avnet Spartan-6 LX9 MicroBoard Configuration Guide
from the Avnet DRC (Design Resource Center): http://em.avnet.com/s6microboard.
This will be found by clicking on the button at the bottom of the page that
says "Support Files & Downloads". 

STEP 2)  In this document, read the instructions in the section, Configuration and 
Programming via the on-board USB-JTAG Circuitry. then skip Procedure 1 and follow 
Procedure 2. Replace instruction #5 with the following:


5. In this same directory create a batch file.  Open a text editor, such as Notepad, 
and copy the following commands:



cls
echo off
cls
ECHO     *** Spartan-6 LX9 MicroBoard Factory Test Flash Loader with Erase ***
ECHO	------------------------------------------------------------------------
ECHO
rem
rem This batch file will perform a sector erase of the specified length and
rem then write the specified file to the flash starting at address 0..
sfutil -d obp -cr -m N25Q128 -e -fi -w S6_LX9_FPGA_Firmware_V1_00.mcs -t
ECHO
ECHO     Press any key to exit...  




STEP 3) Make sure the S6_LX9_FPGA_Firmware_V1_00.mcs MCS file is in the
same directory as the SFUTIL.exe program and this batch file.

STEP 4) Finish the instructions in Procedure 2.

This will reprogram the Flash on the Spartan-6 LX9 MicroBoard with the Factory Test
Flash Image.  This is the image the board is shipped with.

